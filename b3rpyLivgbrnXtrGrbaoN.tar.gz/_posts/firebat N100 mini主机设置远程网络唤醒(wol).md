---
category_bar: true
math: true
title: firebat N100 mini主机设置远程网络唤醒(wol)
tags: [linux,wol,局域网]
categories:
  - linux
date: 2024-10-01 16:58:04
---
## WOL

WoL（Wake-on-LAN）是一种允许通过网络远程打开计算机的协议。wolcmd 是一个常用于发送“魔法包”（Magic Packet）来唤醒计算机的命令行工具。

## BIOS设置

在BIOS中找到与网络唤醒相关的设置，这可能在“Power Management”、“Advanced”或“Integrated Peripherals”等菜单下。常见的选项有“Wake on LAN”、“Power on by PCI-E/PCI”、“Power on by Onboard LAN”等。我这块主板的设置在Boot->network stack

启用网络唤醒：将找到的网络唤醒选项设置为“Enabled”。

如果BIOS不支持，那别玩儿了。

## 系统设置

### 安装ethtool

```shell
sudo apt install ethtool
```

获取安装位置,比如 `/usr/sbin/ethtool`

```shell
which ethtool
```

### 获取网卡名称

```shell
ip a
```

列出所有网卡，找到需要用作唤醒网口的网卡名称，比如我这里的 `enp3s0`
![image](https://xinhaojin.github.io/picx-images-hosting/20241001/image.5tqzzhajc8.png)

### 注册系统服务

```
sudo vi /etc/systemd/system/wol.service
```

```ini
[Unit]
Description=Configure Wake On LAN
 
[Service]
Type=oneshot
ExecStart=/usr/sbin/ethtool -s enp3s0 wol g
 
[Install]
WantedBy=basic.target
```

```shell
sudo systemctl daemon-reload
sudo systemctl start wol.service
sudo systemctl enable wol.service
systemctl status wol
```

### 获取MAC地址

```shell
ip link show enp3s0
```

## 客户端网络唤醒
### windows
eg.Windows下，安装wolcmd(https://www.depicus.com/downloads/wolcmd.zip)

唤醒命令格式

```shell
wolcmd MAC IP/Domain subnetmask
```

```shell
wolcmd 68:1d:xx:xx:55:9a 192.168.31.31 255.255.255.0
```

唤醒速度特别快，我键盘回车键按下还没弹起来，机器电源指示灯就已经亮了
![image](https://xinhaojin.github.io/picx-images-hosting/20241001/image.70ab83e0zu.jpg)
### linux
```shell
sudo apt-get install wakeonlan
wakeonlan -i 192.168.31.31 68:1d:xx:xx:55:9a
```
## 注意事项
测试发现公网通过域名方式没法唤醒，理论上应该是可行的，但实际这个魔法包传输过程中很有可能受到防火墙或其他安全策略的阻碍

此外，关机方式不同也会有区别，我尝试使用`shutdown now`,`halt`,`poweroff`来关机，然后分别尝试唤醒，发现通过`halt`方式关机后不支持唤醒,虽然这个方式反而是留下电源指示灯通电的。

