---
category_bar: true
math: true
title: DHCP故障排查，另起一个DHCP服务器竟然还不行，原因竟是下级路由器以下犯上
tags: [DHCP,linux]
categories:
  - 软件安装配置
  - linux
date: 2024-10-16 21:40:04
---
## 前言
家里小米路由器局域网网段是192.168.31.0/24，但很多设备经常会获取到192.168.1.0/24网段的IP，导致上不了网，让人非常恼火。
经常之前有段时间我误以为是光猫DHCP服务没有彻底关闭导致的，但我最近仔细琢磨了一下才想起来我的光猫其实设置的网段是192.168.10.0/24网段，所以不是光猫的问题，而是DHCP服务故障。

家里连接的设备大概在20个左右，之前装宽带的师傅就跟我说不要在光猫lan口直接接交换机，应该买个性能好一点的路由器来做DHCP服务器，我想我的红米AX6000主路由应该足够强了，但还是莫名其妙的出现获取不到IP的情况，搞得人非常火大，于是决定另起一个DHCP服务。
## 安装配置
```shell
sudo apt install isc-dhcp-server
```
修改`/etc/dhcp/dhcpd.conf`
```conf
# 定义全局选项
option domain-name-servers 223.5.5.5,223.6.6.6; # 使用阿里DNS服务器

# 定义子网
subnet 192.168.31.0 netmask 255.255.255.0 {
    range 192.168.31.2 192.168.31.220; # 指定IP地址分配范围
    option routers 192.168.31.1; # 指定网关
    option subnet-mask 255.255.255.0; # 指定子网掩码
    option domain-name-servers 223.5.5.5,223.6.6.6; # 指定DNS服务器
    authoritative;
}
# 日志
# grep dhcp /var/log/syslog
```
修改`/etc/default/isc-dhcp-server`,指定配置文件路径和网络接口名称
```conf
DHCPDv4_CONF=/etc/dhcp/dhcpd.conf
INTERFACESv4="enp3s0"
INTERFACESv6="enp3s0"
```
设置为开机自启动
```shell
sudo systemctl start isc-dhcp-server
sudo systemctl enable isc-dhcp-server
```
然后关闭路由器的DHCP服务
## 测试
手机忘记此网络，重新连接，给我气笑了，获取到了192.168.1.100的IP，根本不是我的网段

查看日志
```shell
grep dhcp /var/log/syslog
```
```shell
2024-10-17T21:26:57.401204+08:00 firebat-server dhcpd[2087508]: DHCPDISCOVER from c2:02:42:75:22:f5 (CET-AL00) via enp3s0
2024-10-17T21:26:57.467998+08:00 firebat-server dhcpd[2087508]: DHCPREQUEST for 192.168.1.100 (192.168.1.1) from c2:02:42:75:22:f5 via enp3s0: wrong network.
2024-10-17T21:26:57.468319+08:00 firebat-server dhcpd[2087508]: DHCPNAK on 192.168.1.100 to c2:02:42:75:22:f5 via enp3s0
2024-10-17T21:26:57.596163+08:00 firebat-server dhcpd[2087508]: DHCPREQUEST for 192.168.1.100 (192.168.1.1) from c2:02:42:75:22:f5 via enp3s0: wrong network.
2024-10-17T21:26:57.596290+08:00 firebat-server dhcpd[2087508]: DHCPNAK on 192.168.1.100 to c2:02:42:75:22:f5 via enp3s0
2024-10-17T21:26:58.402446+08:00 firebat-server dhcpd[2087508]: DHCPOFFER on 192.168.31.5 to c2:02:42:75:22:f5 (CET-AL00) via enp3s0
2024-10-17T21:27:05.243708+08:00 firebat-server dhcpd[2087508]: DHCPREQUEST for 192.168.1.119 from 24:27:30:4d:30:38 via enp3s0: wrong network.
2024-10-17T21:27:05.244090+08:00 firebat-server dhcpd[2087508]: DHCPNAK on 192.168.1.119 to 24:27:30:4d:30:38 via enp3s0
2024-10-17T21:27:05.276043+08:00 firebat-server dhcpd[2087508]: DHCPDISCOVER from 24:27:30:4d:30:38 via enp3s0
2024-10-17T21:27:05.297040+08:00 firebat-server dhcpd[2087508]: DHCPREQUEST for 192.168.1.119 (192.168.1.1) from 24:27:30:4d:30:38 via enp3s0: wrong network.
2024-10-17T21:27:05.297336+08:00 firebat-server dhcpd[2087508]: DHCPNAK on 192.168.1.119 to 24:27:30:4d:30:38 via enp3s0
2024-10-17T21:27:06.278249+08:00 firebat-server dhcpd[2087508]: DHCPOFFER on 192.168.31.195 to 24:27:30:4d:30:38 via enp3s0
```
日志显示有个192.168.1.1的狗东西TMD在积极地给我分配错误的IP，导致我的手机优先获取到了192.168.1.1这个DHCP服务器分配的IP。在我家的网络中，这只有可能是我192.168.31.1主路由的下级路由器。
## 排障
```shell
ping 192.168.1.1
```
可以ping通
```shell
正在 Ping 192.168.1.1 具有 32 字节的数据:
来自 192.168.1.1 的回复: 字节=32 时间=3ms TTL=251
来自 192.168.1.1 的回复: 字节=32 时间=3ms TTL=251

192.168.1.1 的 Ping 统计信息:
    数据包: 已发送 = 2，已接收 = 2，丢失 = 0 (0% 丢失)，
往返行程的估计时间(以毫秒为单位):
    最短 = 3ms，最长 = 3ms，平均 = 3ms
```
安装局域网扫描工具
```shell
sudo apt install arp-scan
arp-scan 192.168.1.0/24
```
```shell
Interface: enp3s0, type: EN10MB, MAC: 68:1d:ef:40:55:9a, IPv4: 192.168.31.31
Starting arp-scan 1.10.0 with 256 hosts (https://github.com/royhills/arp-scan)
192.168.1.1     00:5c:c2:45:87:4f       SHENZHEN MERCURY COMMUNICATION TECHNOLOGIES CO.,LTD.
192.168.1.108   c8:bf:4c:31:5b:16       Beijing Xiaomi Mobile Software Co., Ltd
192.168.1.113   a4:39:b3:ca:23:42       Beijing Xiaomi Mobile Software Co., Ltd
192.168.1.217   b0:59:47:8e:f7:21       Shenzhen Qihu Intelligent Technology Company Limited
192.168.1.119   24:27:30:4d:30:38       (Unknown)

5 packets received by filter, 0 packets dropped by kernel
Ending arp-scan 1.10.0: 256 hosts scanned in 1.929 seconds (132.71 hosts/sec). 5 responded
```
明显是个水星路由器

再扫一下我的31网段
```shell
arp-scan 192.168.31.0/24
```
```shell
Interface: enp3s0, type: EN10MB, MAC: 68:1d:ef:40:55:9a, IPv4: 192.168.31.31
Starting arp-scan 1.10.0 with 256 hosts (https://github.com/royhills/arp-scan)
192.168.31.1    24:cf:24:5d:64:da       Beijing Xiaomi Mobile Software Co., Ltd
192.168.31.2    b0:59:47:8e:f7:21       Shenzhen Qihu Intelligent Technology Company Limited
192.168.31.32   80:fa:5b:4e:ba:96       CLEVO CO.
192.168.31.5    c2:02:42:75:22:f5       (Unknown: locally administered)
192.168.31.6    d4:35:38:14:4f:4f       Beijing Xiaomi Mobile Software Co., Ltd
192.168.31.3    68:ab:bc:ed:68:aa       Beijing Xiaomi Mobile Software Co., Ltd
192.168.31.72   d4:bb:e6:64:60:29       Huawei Device Co., Ltd.
192.168.31.34   b8:ab:62:ae:a5:a3       Hui Zhou Gaoshengda Technology Co.,LTD
192.168.31.100  58:11:22:4a:95:91       ASUSTek COMPUTER INC.
192.168.31.166  50:88:11:d7:66:b9       (Unknown)
192.168.31.194  44:e6:4a:53:48:ac       (Unknown)
192.168.31.80   4c:11:ae:01:22:29       Espressif Inc.
192.168.31.130  50:2c:c6:09:f2:08       GREE ELECTRIC APPLIANCES, INC. OF ZHUHAI

14 packets received by filter, 0 packets dropped by kernel
Ending arp-scan 1.10.0: 256 hosts scanned in 1.940 seconds (131.96 hosts/sec). 13 responded
```
没有192.168.1.1那个MAC地址的IP，我都不知道他是怎么上网的。

神奇的是有一个MAC为`b0:59:47:8e:f7:21`的设备，同时拥有两个网段的IP：192.168.31.2和192.168.1.217 ，生产厂商是Shenzhen Qihu Intelligent Technology Company Limited，qihu奇虎应该是360的东西，应该是我的无线摄像头，点开摄像头app一看IP果然是,小小摄像头获取了两个IP，设计的还比较聪明，有两个DHCP服务器就配置两个IP，这样能上网的概率高得多，其他设备要是有这么聪明就好了，不愧是360。

接下来我手机登录到内网机器宝塔面板的终端，一根根拔网线排查，每拔一次就输入`arp-scan 192.168.1.0/24`看一下192.168.1.1那个设备还在不在。果然，两三下就被我找到了罪魁祸首。

一看果然是水星路由器，登上去管理地址之后发现上网方式是宽带上网...，还改不了设置，看了下网口，网线插在了LAN口...，我都无语了，怪不得会以下犯上，他以为我是他的下级呢。

网线插了WAN口之后可以设置自动获取IP，这时候就正常了。

这也意味着我的路由器DHCP可以重新开启，内网ubuntu的DHCP可以关闭。但是不改了，先用着，总比路由器的DHCP服务能力强。


