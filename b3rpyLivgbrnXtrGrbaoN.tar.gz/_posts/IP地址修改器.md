---
category_bar: true
math: true
title: IP地址修改器
index_img: https://xinhaojin.github.io/imgs-host/20240827/1724732053037.jpg
tags: [IP,python]
categories:
  - python
  - 杂
date: 2024-08-27 12:02:30
---
在需要频繁换IP地址的情况下，打开网络设置去修改比较慢，因此设计一个IP地址修改器，可以快速修改IP

## 代码

```python
import os
import re

class IpManage:
    def __init__(self):
        self.ip_list = self.get_ip()

    def set_ip(self, name, ip, mask, gateway):
        # 设置静态IP地址
        os.system(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"netsh interface ip set address name=\"{name}\" static {ip} ]em(f"net