---
category_bar: true
math: true
title: flask+gunicorn+vue+nginx Linux部署案例
tags: [flask,python,nginx,linux]
categories:
  - python
  - linux
date: 2024-09-30 14:55:00
---
## 前言

假设现在拥有：

- flask后端代码：由flask_app.py作为启动程序
- vue前端代码,且已经打包成dist文件夹

## 什么是Gunicorn

Gunicorn（“Green Unicorn”的缩写）是一个Python WSGI HTTP服务器，用于生产环境。它是一个预分叉的服务器，可以与多个工作进程一起运行，以处理并发请求。Gunicorn旨在解决Python web应用在生产环境中运行时的性能问题。

## flask配置

flask_app.py
因为Gunicorn 会接管 Flask 应用的监听端口，所以不需要在 Flask 应用中指定端口

```python
# .......
if __name__ == '__main__':
    app.run(host="0.0.0.0", threaded=True)
```

## guncorn配置

新建guncorn_config.py

设置监听端口为54322

```python
from gevent import monkey
monkey.patch_all()
# 必须加上这两行，否则，由于某些模块在Gunicorn尝试monkey patch SSL之前已经被导入
# 会产生警告，这可能导致错误。为了避免这些问题，需要在导入其他依赖库之前先进行monkey patching，可以在本文件中写，也可以在主函数开头写
# gevent的猴子补丁会替换掉Python标准库中的一些函数和方法，使得原本阻塞的操作变得非阻塞
# 这意味着Gunicorn使用了协程来提高并发能力。
# 这种模式下，理论上单个工作进程就能处理大量的并发连接，因为每个连接并不需要消耗一个完整的操作系统线程。
# 如果请求的处理主要是CPU密集型的，增加更多的工作进程和线程可能并不会显著提升性能，反而可能因为上下文切换而造成性能下降
# Gunicorn配置文件
# bind - 绑定的IP地址和端口
bind = '0.0.0.0:54322'
# workers - 启动的工作进程数量
workers = 4
# threads = 4
# worker_class - 工作进程类型，'sync'代表同步模式，还有其他异步模式如gevent和eventlet
# worker_class = 'sync'
worker_class = 'gevent'
# timeout - 工作进程的超时时间，单位为秒
timeout = 30
# preload_app - 是否在每个工作进程中预加载应用
preload_app = True
# loglevel - 日志级别，可选值有'debug', 'info', 'warning', 'error', 'critical'
loglevel = 'info'
# accesslog - 访问日志的输出位置，'-'表示输出到标准输出
accesslog = '-'
# errorlog - 错误日志的输出位置，'-'表示输出到标准输出
errorlog = '-'
# capture_output - 是否捕获标准输出和标准错误流到日志中
capture_output = True
```

由gunicorn托管flask

```shell
gunicorn -c gunicorn_config.py flask_app:app &
# 关闭服务
# lsof -ti :54322 | xargs kill -9
```

## nginx配置

/etc/nginx/nginx.conf

在HTTP中添加以下两个Server

- 第一个Server的作用是监听8080端口，指定前端静态资源目录
- 第二个Server的作用是监听54321端口，反向代理前端对54321端口的请求，转发给54322端口的gunicorn程序

```conf
    server {
        listen 8080;
        server_name _; # 替换为您的域名或IP地址
        root /usr/share/nginx/html/dist;
        location /static/ {
            autoindex on;
            alias /usr/share/nginx/html/dist/static/; # 指定静态资源目录
        }
    }
    server {
        listen 54321;
        server_name _; # 替换为您的域名或IP地址
        location / {
            # add_header Access-Control-Allow-Origin *;
            try_files $uri $uri/  /index.html =404;
            index index.html index.htm;
            proxy_pass http://127.0.0.1:54322; # Gunicorn监听的地址和端口
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }
    }
```
