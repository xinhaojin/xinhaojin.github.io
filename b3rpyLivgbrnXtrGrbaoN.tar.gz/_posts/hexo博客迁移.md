---
category_bar: true
math: true
title: hexo博客迁移
tags: [blog,linux]
categories:
  - 杂
date: 2023-07-04 19:30:00
---
## hexo博客迁移

### 背景

最开始使用wordpress写博客，方便是方便，但感觉不够干净、不够优雅，所以后来开始写markdown格式的博客，使用hexo部署在github上，但是平时使用的电脑有很多台，GitHub上公开的又只有public文件夹的静态页面，没有把markwodn文件一并提交，因此也不能通过github来同步，所以就想干脆把hexo项目放在云服务器上，要写新文章就写好markdown上传到云服务器去提交，也省的在各个电脑上配置。本文简要介绍把hexo项目迁移到云服务器上的步骤。

- 2024.10.2第二次修改，不再部署到云服务器，以下是在本地新机器上的部署步骤

### 安装nodejs、Hexo和其他依赖

``````shell
sudo apt-get install nodejs
sudo apt-get install npm
npm install -g hexo-cli
mkdir blog
cd blog
hexo init
npm install
npm install hexo-deployer-git --save
# 主题
npm install --save hexo-theme-fluid
# 评论插件
npm i --save gitalk
``````

### 建立git连接

``````shell
git config --global user.name "xinhaojin"
git config --global user.email "xinhaojin@qq.com"
ssh-keygen -t rsa -b 4096 -C "xinhaojin@qq.com"
``````

把公钥/root/.ssh/id_rsa.pub中的内容添加到github-setting-ssh key

### 配置文件

修改_config.yml

```
title: xinhaojin's blog
keywords:
author: xinhaojin
language: zh-CN

theme: fulid
deploy:
  type: 'git'
  repository:  git@github.com:xinhaojin/xinhaojin.github.io.git
  branch: main
```

### 更新博客

上传markdown到blog/source/_posts文件夹
然后就可以发布新文章了

```shell
hexo clean
hexo g
hexo d
```

markdown模板

```
---
title: 文章标题
tags: []
categories:
  - - 软件安装配置
date: 2023-05-20 13:30:00
---
## xxx
### xxx
![](url)
<url>
```
